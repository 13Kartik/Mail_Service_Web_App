const express = require('express');
const router = express.Router();
const Ctrl = require('../controller/mail.controller');

router.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});


router.post('/register',Ctrl.register);
router.post('/login',Ctrl.login);
router.post('/getUserInfo',Ctrl.getUserInfo);
router.post('/save_mail',Ctrl.save_mail);
router.post('/add_tag',Ctrl.add_tag);
router.post('/remove_tag',Ctrl.remove_tagStatus);
router.post('/get_received_mailList',Ctrl.get_received_mailList);
router.post('/get_sent_mailList',Ctrl.get_sent_mailList);
router.post('/get_trash_mailList',Ctrl.get_trash_mailList);
router.post('/get_spam_mailList',Ctrl.get_spam_mailList);
router.post('/get_mailData',Ctrl.get_mailData);
router.post('/get_tagList',Ctrl.get_tagList);
router.post('/moveTo_trash',Ctrl.moveTo_trash);
router.post('/recoverMails',Ctrl.recoverMails);
router.post('/get_filteredMails',Ctrl.get_filteredMails);
router.post('/get_emailStatusId',Ctrl.get_emailStatusId);
router.post('/get_activeTags',Ctrl.get_activeTags);
router.post('/deleteMails',Ctrl.deleteMails);
router.post('/markAsRead',Ctrl.markAsRead);
router.post('/markAsSpam',Ctrl.markAsSpam);
router.post('/removeFromSpam',Ctrl.removeFromSpam);



module.exports = router;