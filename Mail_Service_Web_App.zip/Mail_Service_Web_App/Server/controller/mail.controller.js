const { json } = require('express');
const db = require('../db/mail.dbConnection');

function register(req,res){
    let userInfo = req.body;
    console.log(userInfo);
    let values = [];
    for(let key in userInfo){
        values.push(userInfo[key]);
    }
    let query = 'INSERT INTO users (`firstName`,`lastName`,`mobileNumber`,`dateOfBirth`,`email`,`userPassword`) VALUES (?)';
    db.query(query,[values],function(err,data){
        if(err){
            console.log(err);
        }
        else{
            console.log('user registered');
            return res.status(200).json({
                code:200
            });
        }
    });
}

function login(req,res){
    let userInfo = req.body;
    console.log('userInfo:  ',userInfo['email']);

    let query = 'SELECT id FROM `users` WHERE email= ? AND userPassword = ?';
    db.query(query,[userInfo['email'],userInfo['password']],function(err,id){
        if(err){
            console.log(err);
        }
        else{
            return res.status(200).json(id[0]);
        }
    });
}

// function save_mail(req,res){
//     let mail = req.body;
//     let values=[];
//     for(let key in mail){
//         values.push(mail[key]);
//     }

//     //get id from email address
//     let query = 'SELECT id FROM users where email = ?';
//     db.query(query,values[1],function(err,data){
//         if(err){
//             console.log(err);
//             throw err;
//         }
//         else{
//             console.log(data);
//             values[1]=data[0]['id'];
//             query = 'INSERT INTO email(senderId,receiverId,ccId,bccId,subject,mailBody) values (?)';
//             db.query(query,[values],function(err,data){
//                 if(err){
//                     console.log(err);
//                     return res.status(500).json({
//                         code:500
//                     })
//                 }
//                 else{
//                     //INSERT ROW FOR EMAIL STATUS FOR EACH USER
//                     setMailStatus(values[0],data.insertId);
//                     setMailStatus(values[1],data.insertId);
//                     return res.status(200).json({
//                         code:200
//                     })
//                 }
//             });
//         }
//     });
// }

function save_mail(req,res){
    console.log('received data: ',req.body);
    let subject = req.body['subject'];
    let mailBody = req.body['txt'];

    let query = 'INSERT INTO email (subject,mailBody) VALUES (?)';
    db.query(query,[[subject,mailBody]],function(err,data){
        if(err){
            console.log(err);
        }
        else{
            let mailUsers = req.body['mailUsers'];
            let emailId = data.insertId;
            let senderId = req.body['senderId'];

            save_emailSender(emailId,senderId);

            for(let user of mailUsers){
                save_emailUser(emailId,user['email'],user['userType']);
            }
        }
    });


}

function setMailStatus(userId,emailId){
    let query = 'INSERT INTO emailstatus (userId,emailId) VALUES (?)';
    db.query(query,[[userId,emailId]],function(err,data){
        if(err){
            console.log(err);
        }
        else{
            console.log('email status inserted.');
        }
    });
}


function get_received_mailList(req,res){
    let id = req.body['id'];

    let query = "SELECT email.id,email.subject,email.mailBody,emailstatus.inTrash,emailstatus.unread,emailstatus.spam FROM email INNER JOIN emailusers ON emailusers.emailId = email.id INNER JOIN emailstatus ON email.id=emailstatus.emailId AND emailstatus.userId = emailusers.userId where emailstatus.inTrash=0 AND emailstatus.spam=0 AND (emailusers.userType = 'receiver' || emailusers.userType = 'cc' || emailusers.userType = 'bcc') AND emailusers.userId = ?";

    db.query(query,id,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            return res.status(200).json({
                code:200,
                data:data
            });
        }
    });
}

function get_sent_mailList(req,res){
    let id = parseInt(req.body['id']);

    let query = "SELECT email.id,email.subject,email.mailBody,emailstatus.inTrash,emailstatus.unread,emailstatus.spam FROM email INNER JOIN emailusers ON emailusers.emailId = email.id INNER JOIN emailstatus ON email.id=emailstatus.emailId AND emailstatus.userId = emailusers.userId where emailstatus.inTrash=0 AND emailstatus.spam=0 AND emailusers.userType = 'sender' AND emailusers.userId = ?";
    db.query(query,id,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            return res.status(200).json({
                code:200,
                data:data
            });
        }
    });
}

function get_trash_mailList(req,res){
    let id = parseInt(req.body['id']);

    let query = "SELECT email.id,email.subject,email.mailBody,emailstatus.inTrash,emailstatus.unread,emailstatus.spam FROM email INNER JOIN emailusers ON emailusers.emailId = email.id INNER JOIN emailstatus ON email.id=emailstatus.emailId AND emailstatus.userId = emailusers.userId WHERE emailstatus.inTrash=1 AND (emailusers.userType = 'receiver' || emailusers.userType = 'sender') AND emailusers.userId = ?";
    db.query(query,id,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            return res.status(200).json({
                code:200,
                data:data
            });
        }
    });
}

function get_spam_mailList(req,res){
    let id = parseInt(req.body['id']);

    let query = "SELECT email.id,email.subject,email.mailBody,emailstatus.inTrash,emailstatus.unread,emailstatus.spam FROM email INNER JOIN emailusers ON emailusers.emailId = email.id INNER JOIN emailstatus ON email.id=emailstatus.emailId AND emailstatus.userId = emailusers.userId WHERE emailstatus.spam=1 AND emailstatus.inTrash=0 AND (emailusers.userType = 'receiver' || emailusers.userType = 'sender') AND emailusers.userId = ?";
    db.query(query,id,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            return res.status(200).json({
                code:200,
                data:data
            });
        }
    });
}

function get_emailStatusId(req,res){
    let userId = req.body['userId'];
    let emailId = req.body['emailId'];

    let query = 'SELECT id,spam FROM emailstatus WHERE emailId = '+emailId;
    query += ' AND userId = '+userId;

    db.query(query,function(err,data){
        if(err){
            console.log(err);
        }
        else{
            res.status(200).json({
                data:data
            });
        }
    });
}

function get_activeTags(req,res){
    let emailStatusId = req.body['id'];
    console.log('id: ',emailStatusId);

    let query = 'SELECT tags.name FROM tags INNER JOIN tagstatus ON tagstatus.tagId=tags.id WHERE tagstatus.emailstatusId = ?'

    db.query(query,emailStatusId,function(err,data){
        if(err){
            console.log(err);
        }
        else{
            console.log('active Tag: ',data);
            res.status(200).json({
                data:data
            });
        }
    });
}

function get_mailData(req,res){
    let emailId = req.body['emailId'];

    let query = 'SELECT email.subject, email.mailBody, emailusers.userId as receiverId, users.firstName, users.lastName, users.email FROM email'; 

    query += ' INNER JOIN emailstatus ON email.id = emailstatus.emailId';

    query += ' INNER JOIN emailusers ON emailusers.emailId = email.id';
    query += ' INNER JOIN users ON users.id = emailusers.userId AND users.id = emailstatus.userId';
    query += " WHERE emailusers.userType = 'sender' AND email.id = "+emailId;

    db.query(query,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            return res.status(200).json({
                code:200,
                data:data
            });
        }
    });
}

function moveTo_trash(req,res){
    let userId = req.body['userId'];
    let id_list = req.body['id_list'];

    //query
    let query = 'UPDATE emailstatus SET inTrash = 1 WHERE userId = ' ;
    query +=userId;
    query += ' AND emailId IN (?)';


    db.query(query,[id_list],function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            console.log('moved to trash');
            return res.status(200).json({
                code:200,
            });
        }
    });
}

function recoverMails(req,res){
    let userId = req.body['userId'];
    let id_list = req.body['id_list'];

    //query
    let query = 'UPDATE emailstatus SET inTrash = 0 WHERE userId = ' ;
    query +=userId;
    query += ' AND emailId IN (?)';

    db.query(query,[id_list],function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            console.log('moved to inbox');
            return res.status(200).json({
                code:200,
            });
        }
    });
}


function getUserInfo(req,res){
    let id =req.body['id'];
    
    let query = 'SELECT firstName,lastName,email FROM users where id = ?';
        db.query(query,id,function(err,data){
            if(err){
                console.log(err);
                throw err;
            }
            else{
                return res.status(200).json({
                    data:data
                });
            }
    });
}

function deleteMails(req,res){
    let userId = req.body['userId'];
    let id_list = req.body['id_list'];

    //query
    let query = 'DELETE FROM emailstatus WHERE userId = ' ;
    query +=userId;
    query += ' AND emailId IN (?)';

        db.query(query,[id_list],function(err,data){
            if(err){
                console.log(err);
                throw err;
            }
            else{
                console.log('mail status deleted for user.');

                for(let id of id_list)
                    checkMailUsers(id);

                return res.status(200).json({
                    code:200
                });
            }
    });
}

function markAsRead(req,res){
    let userId = req.body['userId'];
    let emailId = req.body['emailId'];

    let query = 'UPDATE emailstatus SET unread = 0 WHERE userId = ' ;
    query +=userId;
    query += ' AND emailId = ?';

    db.query(query,emailId,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            console.log('mail marked as read');
            return res.status(200).json({
                code:200,
            });
        }
    });
}

function markAsSpam(req,res){
    let id =req.body['id'];

    let query = 'UPDATE emailstatus SET spam = 1 WHERE id = ?' ;

    db.query(query,id,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            console.log('mail marked as spam');
            return res.status(200).json({
                code:200,
            });
        }
    });
}

function removeFromSpam(req,res){
    let id =req.body['id'];

    let query = 'UPDATE emailstatus SET spam = 0 WHERE id = ?' ;

    db.query(query,id,function(err,data){
        if(err){
            console.log(err);
            throw err;
        }
        else{
            console.log('removed from spam');
            return res.status(200).json({
                code:200,
            });
        }
    });
}



function checkMailUsers(emailId){
    let query = 'SELECT * FROM emailstatus WHERE emailId = ?'
    db.query(query,emailId,function(err,data){
        if(err){
            console.log(err);
        }
        else{
            //if every user deleted it,delete it from database
            if(data.length==0){
                removeFromDb(emailId);
            }
        }
    });
}

function removeFromDb(emailId){
    //query
    let query = 'DELETE FROM email WHERE id = ?';

        db.query(query,emailId,function(err,data){
            if(err){
                console.log(err);
                throw err;
            }
            else{
                console.log('email removed from database.');
            }
    });
}

function add_tag(req,res){
    let tagData = req.body;
    console.log(tagData);

    //check if tag exist for user or not
    let query = 'SELECT id FROM tags where userId = '+tagData['userId'];

    query += ' AND name = ?';
    db.query(query,tagData['tagName'],function(err,data){
        if(err){
            console.log(err);
        }
        else{
            console.log(data);

            //if tag does exist for user then add new record in database 
            if(data.length==0){
                let query = 'INSERT INTO tags(`name`,`userId`) VALUES (?)';
                db.query(query,[[tagData['tagName'],tagData['userId']]],function(err,data){
                    if(err){
                        console.log(err);
                    }
                    else{
                        console.log('tag added into database for user');
                        add_tagStatus(tagData['emailStatusId'],data.insertId);
                    }
                });
            }
            else{//if tag already exist for user
                add_tagStatus(tagData['emailStatusId'],data[0]['id']);
            }
        }
    });
}

function remove_tagStatus(req,res){

    let emailStatusId = req.body['emailStatusId'];
    let tagName = req.body['tagName'];

    let query = 'DELETE tagstatus FROM tagstatus';
    query += ' INNER JOIN tags ON tags.id = tagstatus.tagId' 
    query += ' WHERE tagstatus.emailstatusId = ';
    query += emailStatusId;
    query += ' AND tags.name = ?';

    db.query(query,tagName,function(err,data){
        if(err){
            console.log(err);
        }
        else{
            console.log('tag removed for mail.');
            return res.status(200).json({
                code:200
            });
        }
    });
}


function add_tagStatus(emailStatusId,tagId){

    console.log('status Id: ',emailStatusId,'\ntagId:',tagId)

    //check if user already set this tag for same mail or not
    let query = 'SELECT * FROM tagstatus where emailstatusId = '+emailStatusId+' AND tagId = '+tagId;

    db.query(query,function(err,data){
        if(err){
            console.log(err);
        }
        else{
            //if tag is not set for mail then set it
            if(data.length==0){
                let query = 'INSERT INTO tagstatus(`emailstatusId`,`tagId`) VALUES (?)'

                db.query(query,[[emailStatusId,tagId]],function(err,data){
                    if(err){
                        console.log(err);
                    }
                    else{
                        console.log('tagStatus added for user');
                    }
                });
            }
            else{
                console.log('this tag is already set for this mail');
            }
        }
    });
}



function get_tagList(req,res){
    let userId = req.body['userId'];

    let query = 'SELECT name FROM tags WHERE userId = ?';

    db.query(query,userId,function(err,data){
        if(err){
            console.log(err);
        }
        else{
            res.status(200).json({
                data:data
            });
        }
    });

}

function get_filteredMails(req,res){
    let userId = req.body['userId'];
    let tagList = req.body['tagList'];
    let userType = req.body['userType'];
    console.log('tagList',tagList);

    let query = 'SELECT email.id,email.subject,email.mailBody,emailstatus.inTrash,emailstatus.unread FROM email';
    query += ' INNER JOIN emailstatus ON email.id = emailstatus.emailId';
    query += ' INNER JOIN tagstatus ON tagstatus.emailstatusId = emailstatus.id';
    query += ' INNER JOIN tags ON tags.id = tagstatus.tagId';

    if(userType=='sender')
        query += ' where email.senderId = ' + userId; 

    else if(userType=='receiver')
        query += ' where email.receiverId = ' + userId; 

    else
        query += ' where emailstatus.userId = ' + userId; 

        query += ' AND emailstatus.spam = 0';
        query += ' AND tags.name in (?)';

    db.query(query,[tagList],function(err,data){
        console.log(data);
        if(err){
            console.log(err);
        }
        else{
            res.status(200).json({
                data:data
            });
        }
    });
}

function save_emailUser(emailId,email,userType){
    if(email!=''){

    let query = 'SELECT id FROM users where email = ?';

    db.query(query,email,function(err,data){
        if(err){
            console.log(err);
        }
        else{
            console.log(data);
            let userId = data[0]['id'];
            let query = 'INSERT INTO `emailusers` (emailId,userId,userType) VALUES (?)';

            db.query(query,[[emailId,userId,userType]],function(err,data){
                if(err){
                    console.log(err);
                }
                else{
                    console.log('email user inserted');
                    //add email status
                    setMailStatus(userId,emailId);
                }
            });
        }
    });
}
}

function save_emailSender(emailId,userId){

    let query = 'INSERT INTO `emailusers` (emailId,userId,userType) VALUES (?)';

    db.query(query,[[emailId,userId,'sender']],function(err,data){
        if(err){
            console.log(err);
        }
        else{
            console.log('email user inserted');
            //add email status
            setMailStatus(userId,emailId);
        }
    });
}


module.exports = {
    register,
    login,
    getUserInfo,
    save_mail,
    get_received_mailList,
    get_sent_mailList,
    moveTo_trash,
    recoverMails,
    get_mailData,
    markAsRead,
    add_tag,
    remove_tagStatus,
    get_tagList,
    get_filteredMails,
    get_emailStatusId,
    get_trash_mailList,
    get_spam_mailList,
    markAsSpam,
    removeFromSpam,
    get_activeTags,
    deleteMails
}