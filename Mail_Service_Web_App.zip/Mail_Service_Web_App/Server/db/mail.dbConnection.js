const mysql = require('mysql');

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mail_service'
});

con.connect(function (err,res) {
    if (err) {
        res.json({
            code: 500,
            message: 'Something went wrong!',
            error: err
        });
    }
});

module.exports = con;