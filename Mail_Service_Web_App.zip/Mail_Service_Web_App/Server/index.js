const express = require('express');
const bodyparser = require('body-parser');
const Route = require('./routes/mail.route');

let app = express();
app.use(bodyparser.json());
const port = 3000;

app.use('/', Route);

app.listen(port,(err)=>{
    if (err) {
        console.log('Error to start server =>', err);
    } else {
        console.log('Server start on PORT =' + port);
    }
});
