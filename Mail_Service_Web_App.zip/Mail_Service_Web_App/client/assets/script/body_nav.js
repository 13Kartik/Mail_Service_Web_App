$("#compose-link").attr("href", "./composeMail.html?userId="+get_userId()+'&active=compose&readFilter='+get_readFilter()+'&tagFilter='+get_tagFilter());

$('#slider-close').click(()=>{
    $('.hamburger-menu').animate({left:'-100%'},'fast');
});

function get_userId(){
    let query_string = location.search.substring(1);
    let pattern = /userId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}

function inbox_link(){
    let url='./home.html?userId='+get_userId()+'&active=inbox&readFilter='+get_readFilter()+'&tagFilter='+get_tagFilter();
    window.location.replace(url);
}
function sent_link(){
    let url='./home.html?userId='+get_userId()+'&active=sent&readFilter='+get_readFilter()+'&tagFilter='+get_tagFilter();
    window.location.replace(url);
}
function spam_link(){
    let url='./home.html?userId='+get_userId()+'&active=spam&readFilter='+get_readFilter()+'&tagFilter='+get_tagFilter();
    window.location.replace(url);
}
function trash_link(){
    let url='./home.html?userId='+get_userId()+'&active=trash&readFilter='+get_readFilter()+'&tagFilter='+get_tagFilter();
    window.location.replace(url);
}

function get_tagList(){
    let url = 'http://localhost:3000/get_tagList';
    fetch(url,{
        method:'POST',
        headers:{
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'userId':get_userId()})
    }).then(res=>{
        if(res.ok){
            res.json().then(tags=>{
                set_tagNavlist(tags.data);
            })
        }
    });
}

function set_tagNavlist(tags){

    //removing spam tag

    for (let tag of tags){
        let tag_item = "<li><input class='nav-tag' type='checkbox' value="+tag['name']+'><p>'+tag['name']+'</p> </li>';

        $('#body-nav-tags.nav-tags-list').append(tag_item);
    }
    set_activeTags();
}

function set_tagFilter(){

    //first get checked tags
    let tag_items = document.getElementsByClassName('nav-tag');

    let tagList = [];

    for(let item of tag_items){
        if(item.checked){
            tagList.push(item.value);
        }
    }
    console.log(tagList);
    let url='./home.html?userId='+get_userId()+'&active='+get_activeLink()+'&readFilter=all&tagFilter='+tagList;
    window.location.replace(url);
}

function get_activeLink(){
    let query_string = location.search.substring(1);
    let pattern = /active=(\w*)/;
    let active_link = query_string.match(pattern)[1];
    return active_link;
}

function get_tagFilter(){
    let query_string = location.search.substring(1);
    let pattern = /tagFilter=([^&]*)/;
    let tagFilter = query_string.match(pattern)[1];

    if (tagFilter.length==0)
        return [];
    else
        return tagFilter.split(',');
}

function get_readFilter(){
    let query_string = location.search.substring(1);
    let pattern = /readFilter=(\w*)/;
    let readFilter = query_string.match(pattern)[1];
    return readFilter;
}

function set_activeTags(){

  let parentElement = document.getElementById('body-nav-tags');
  let tag_items = parentElement.querySelectorAll('.nav-tag');
  let tagList = get_tagFilter();

  for (let item of tag_items) {
    item.checked = tagList.includes(item.value);
  }
  
}

function active_nav(){
    let activeLink = get_activeLink();

    let selector = '#'+ activeLink + '-link';

    $(selector).addClass('active');

    //dont needed tags for span or trash mail
    if(activeLink == 'spam' || activeLink == 'trash'){
        $('#navbar-tags').css({'display':'none'})
    }
}

//generate tag check box
get_tagList();
active_nav();