let valid = true;
function registration_btn(){
    valid = true;

    //References
    let References=Object();
    References['fName'] = $('#fname');
    References['lName'] = $('#lname');
    References['dob'] = $('#dob');
    References['mobile'] = $('#mobile');
    References['email'] = $('#email');
    References['password'] = $('#password');   


    //patterns
    let pattern_arry = Object();
    pattern_arry['fName'] =/^[a-zA-Z ]{2,}$/;
    pattern_arry['lName'] =/^[a-zA-Z ]{2,}$/;
    pattern_arry['dob'] = /^\d{4}-\d{2}-\d{2}$/;
    pattern_arry['mobile'] =/^[0-9]{10}$/;
    pattern_arry['email'] =/^\w+@mail\.com$/;
    pattern_arry['password'] = /(\d.*\W)|(\W.*\d)/;

 for(let field in References){
    validate(pattern_arry[field],References[field]);
 }
    if(valid){

        let values = getValues(References);
        register(values);
        References['confirmPassword']=$('#confirmPassword');  
        clearFields(References);
    }
}

function validate(pattern,Reference){
    if(!(pattern.test(Reference.val())))
    {
        Reference.parent().children('.invalid-feedback').css({'visibility':'visible'});
        valid=false;
    }
    else{
        Reference.parent().children('.invalid-feedback').css({'visibility':'hidden'});
    }
}

function clearFields(References){
    for(let Reference in References){
        References[Reference].val('');
    }
}

function getValues(References){
    let values = Object();

    for(let Reference in References){
        values[Reference]=References[Reference].val();
    }

    return values;
}

function register(values){
    let url = 'http://localhost:3000/register';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(values)
    }).then(res=>{
        if(res.ok){
            alert("Your Mail has been registrated");
        }
        else{
            alert("Failed to register mail");
        }
    })
}