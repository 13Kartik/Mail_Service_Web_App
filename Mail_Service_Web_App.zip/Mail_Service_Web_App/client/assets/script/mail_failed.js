let emailId = get_emailId();
let emailStatusId = null;
let activeTags = [];

async function get_mailData(emailId) {
    try {
        const url = 'http://localhost:3000/get_mailData';
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'emailId': emailId })
        });

        if (response.ok) {
            const data = await response.json();
            let mail = data.data[0];
            set_data(mail);
        }
    } catch (error) {
        console.error(error);
    }
}

async function markAsRead(id) {
    try {
        const url = 'http://localhost:3000/markAsRead';
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'userId': get_userId(), 'emailId': id })
        });

        if (response.ok) {
            console.log('marked as read');
        }
    } catch (error) {
        console.error(error);
    }
}

function set_data(mail) {
    $('#subject').html(mail['subject']);
    $('#sender_name').html(mail['firstName'] + ' ' + mail['lastName']);
    $('#sender_mail').html(mail['email']);
    $('#mail_body').html(mail['mailBody']);
    //receiver
    if (mail['receiverId'] != get_userId())
        getReceiverInfo(mail['receiverId']);
}

function get_userId() {
    let query_string = location.search.substring(1);
    let pattern = /userId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}

function get_emailId() {
    let query_string = location.search.substring(1);
    let pattern = /mailId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}

function get_activeLink() {
    let query_string = location.search.substring(1);
    let pattern = /active=(\w*)/;
    let active_link = query_string.match(pattern)[1];
    return active_link;
}

async function getReceiverInfo(id) {
    try {
        const url = 'http://localhost:3000/getUserInfo';
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'id': id })
        });

        if (response.ok) {
            const data = await response.json();
            let receiverMail = data.data[0]['email'];
            $('#receiver_mail').html('to ' + receiverMail);
        }
    } catch (error) {
        console.error(error);
    }
}

async function addTag(tag) {
    try {
        const url = 'http://localhost:3000/add_tag';
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'tagName': tag, 'userId': get_userId(), 'emailStatusId': emailStatusId })
        });

        if (response.ok) {
            console.log('tag added!!!');
        }
    } catch (error) {
        console.error(error);
    }
}

async function get_emailStatusId() {
    try {
        const url = 'http://localhost:3000/get_emailStatusId';
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'userId': get_userId(), 'emailId': emailId })
        });

        if (response.ok) {
            const data = await response.json();
            emailStatusId = data.data[0]['id'];

            if (data.data[0]['spam'] == 1)
                changeSpam_btn();
        }
    } catch (error) {
        console.error(error);
    }
}

function add_tag_btn() {
    let tag = $('#tag-input').val();
    addTag(tag);
}

async function get_tagList() {
    try {
        const url = 'http://localhost:3000/get_tagList';
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'userId': get_userId() })
        });

        if (response.ok) {
            const tags = await response.json();
            set_tagDatalist(tags.data);
            set_taglist(tags.data);
            set_mailTags(activeTags);
        }
    } catch (error) {
        console.error(error);
    }
}

function set_tagDatalist(tags) {
    for (let tag of tags) {
        let option = '<option>' + tag['name'] + '</option>';
        $('#tags-list').append(option);
    }
}

async function spam_btn() {
    let url = '';

    if ($('#spam-btn').attr('class') == 'danger-btn')
        url = 'http://localhost:3000/markAsSpam';
    else
        url = 'http://localhost:3000/removeFromSpam';

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'id': emailStatusId })
        });

        if (response.ok) {
            console.log('marked as spam');
            changeSpam_btn();
        }
    } catch (error) {
        console.error(error);
    }
}

async function get_activeTags() {
    let url = 'http://localhost:3000/get_activeTags';

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 'id': emailStatusId })
        });

        if (response.ok) {
            const data = await response.json();
            activeTags = data.data;
        }
    } catch (error) {
        console.error(error);
    }
}

function changeSpam_btn() {
    let btn = $('#spam-btn');
    if (btn.attr('class') == 'danger-btn') {
        btn.removeClass('danger-btn');
        btn.addClass('success-btn');
        btn.html('Remove From Spam');
    } else {
        btn.removeClass('success-btn');
        btn.addClass('danger-btn');
        btn.html('Mark As Spam');
    }
}

function set_taglist(tags) {
    for (let tag of tags) {
        let tag_item = "<li><input class='nav-tag' type='checkbox' value=" + tag['name'] + '><p>' + tag['name'] + '</p> </li>';
        $('#mail-add-tags.nav-tags-list').append(tag_item);
    }
}

function set_mailTags(tagList) {
    let parentElement = document.getElementById('mail-add-tags');
    let tag_items = parentElement.querySelectorAll('.nav-tag');

    for (let item of tag_items) {
        item.checked = tagList.some(tag => tag.name == item.value);
    }
}

async function init() {
    await get_activeTags();
    await get_mailData(emailId);
    await get_emailStatusId();
    await markAsRead(emailId);
    await get_tagList();
}

init();
