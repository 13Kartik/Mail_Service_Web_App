async function send(){
    let references=getReferences();
    let values=Object();

    values['senderId']=parseInt(get_userId());

    for (let reference in references){
        values[reference] = references[reference].val();
    }

    let mailUsers = [];

    let receivers = values['to'].split(',');
    for(let receiver of receivers){
        mailUsers.push({'email':receiver,'userType':'receiver'});
    }

    let cc = values['cc'].split(',');
    for(let receiver of cc){
        mailUsers.push({'email':receiver,'userType':'cc'});
    }

    let bcc = values['bcc'].split(',');
    for(let receiver of bcc){
        mailUsers.push({'email':receiver,'userType':'bcc'});
    }

    values['mailUsers'] = mailUsers;

    let url = 'http://localhost:3000/save_mail';

    await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(values)
    }).then(res=>{
        if(res.ok){
            alert('Mail has been sent. ');
            clearFields(references);
        }
        else{
            alert('Failed to send mail. ');
        }
    });
}

function getReferences(){
    let references=Object();
    references['to']=$('#to');
    references['cc']=$('#cc');
    references['bcc']=$('#bcc');
    references['subject']=$('#subject');
    references['txt']=$('#mail_txt');

    return references;
}

function clearFields(references){
    for (let reference in references){
        references[reference].val('');
    }
}

function get_userId(){
    let query_string = location.search.substring(1);
    let pattern = /userId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}