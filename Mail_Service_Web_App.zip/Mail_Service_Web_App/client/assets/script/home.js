$('#header').load('header.html');
$('#body_nav').load('body_nav.html');
$('#footer').load('footer.html');


let userId = get_userId();
let active_link = get_activeLink();
let readFilter = get_readFilter();
let tagList = get_tagFilter();

function gen_mail_item(id,subject_str,text_str){
    let mail_list = document.getElementById('mail_list');

    let li = document.createElement('li');
    li.classList.add('mail-item');
    li.setAttribute('id',id);
    mail_list.appendChild(li);

    let pre_container = div_gen(li,'pre-container');

    let cb = document.createElement('input');
    cb.setAttribute('type','checkbox');
    cb.classList.add('mail_cb');
    cb.setAttribute('onclick','showMailOptions()');
    pre_container.appendChild(cb);

    let container = div_gen(li,'text-container');

    let link = document.createElement('a');
    link.href='./mail.html?userId='+userId+'&active='+active_link+'&readFilter='+readFilter+'&mailId='+id+'&tagFilter='+tagList;
    link.classList.add('mail_link');
    container.appendChild(link);

    let sender =  div_gen(link,'mail_sender');
    let sender_txt=div_gen(sender,'truncate');
    sender_txt.innerHTML = subject_str;

    let text = div_gen(link,'mail_text');
    let text_txt=div_gen(text,'truncate');
    text_txt.innerHTML = text_str;

    let hover_group = div_gen(li,'hover-group')

    let remove = document.createElement('input');
    remove.setAttribute('type','image');
    remove.setAttribute('src','assets/img/delete.png');
    remove.classList.add('delete');
    remove.setAttribute('onclick','deleteMail_btn('+id+')');
    hover_group.appendChild(remove);
}

function div_gen(parent,Class){
    let container = document.createElement('div');
    container.classList.add(Class);
    parent.appendChild(container);
    return container;
}

function read_filter_btn(){
    let url='./home.html?userId='+get_userId()+'&active='+active_link+'&readFilter=all&tagFilter='+tagList;

    if(readFilter!='read')
        url='./home.html?userId='+get_userId()+'&active='+active_link+'&readFilter=read&tagFilter='+tagList;
    window.location.replace(url);
}

function unread_filter_btn(){
    let url='./home.html?userId='+get_userId()+'&active='+active_link+'&readFilter=all&tagFilter='+tagList;

    if(readFilter!='unread')
        url='./home.html?userId='+get_userId()+'&active='+active_link+'&readFilter=unread&tagFilter='+tagList;
    window.location.replace(url);
}

function deleteMail_btn(id){

    if(active_link=='trash')
        deleteMails(userId,[id])

    else
        moveTo_trash(userId,[id]);
}


function moveTo_trash(userId,id_list){
    console.log(id_list);
    let url='http://localhost:3000/moveTo_trash';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'userId':userId,'id_list':id_list})
    }).then(res=>{
        if(res.ok){
            for(let id of id_list){
                $('#'+id).remove();
            }
        }
        else{
            console.log('Failed');
        }
    });
}

function deleteMails(userId,id_list){
    console.log(id_list);
    let url='http://localhost:3000/deleteMails';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'userId':userId,'id_list':id_list})
    }).then(res=>{
        if(res.ok){
            for(let id of id_list){
                $('#'+id).remove();
            }
        }
        else{
            console.log('Failed');
        }
    });
}


function deleteSelected(){
    let selected_mails = get_selected_mails();

    if(active_link=='trash')
        deleteMails(userId,selected_mails);

    else
        moveTo_trash(userId,selected_mails);
}


function showMailOptions(){
    let all_cb = document.getElementById('selectAll');
    let cb_lst = document.getElementsByClassName('mail_cb');
    let flag = false;
    let all = true;
    for (cb of cb_lst){
        if(cb.checked){
            flag = true;
        }
        else{
            all = false;
        }
    }
    if(flag){
        $('#deleteSelected').css({'display':'flex'});
        $('#selectAll').css({'visibility':'visible'});

    }
    else{
        $('#deleteSelected').css({'display':'none'});
        $('#selectAll').css({'visibility':'hidden'});
    }
    
    if(all){
        all_cb.checked=true;
    }
    else{
        all_cb.checked=false;
    }

    if(active_link=='trash' && flag){
        $('#recover-mails').css({'display':'block'});
    }
    else{
        $('#recover-mails').css({'display':'none'});
    }
}

function select_all(){
    let all_cb = document.getElementById('selectAll');
    let cb_lst = document.getElementsByClassName('mail_cb');

    if(all_cb.checked){
        for(cb of cb_lst){
            cb.checked=true;
        }
    }
    else
    {
        for(cb of cb_lst){
            cb.checked=false;
        }
    }
    showMailOptions();
}

function get_received_mailList(userId){
    let url = 'http://localhost:3000/get_received_mailList';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'id':userId})
    }).then(res=>{
        if(res.ok){
            res.json().then(data=>{
                display_mails(data.data);
            });
        }
        else{
            console.log('Failed');
        }
    });
}

function get_sent_mailList(userId){
    let url = 'http://localhost:3000/get_sent_mailList';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'id':userId})
    }).then(res=>{
        if(res.ok){
            res.json().then(data=>{
                display_mails(data.data);
            });
        }
        else{
            console.log('Failed');
        }
    });
}

function get_trash_mailList(userId){
    let url = 'http://localhost:3000/get_trash_mailList';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'id':userId})
    }).then(res=>{
        if(res.ok){
            res.json().then(data=>{
                display_mails(data.data);
            });
        }
        else{
            console.log('Failed');
        }
    });
}

function get_spam_mailList(userId){
    let url = 'http://localhost:3000/get_spam_mailList';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'id':userId})
    }).then(res=>{
        if(res.ok){
            res.json().then(data=>{
                display_mails(data.data);
            });
        }
        else{
            console.log('Failed');
        }
    });
}

function display_mails(mails){

    if(readFilter=='all'){
        for(let mail of mails){
            gen_mail_item(mail['id'],mail['subject'],mail['mailBody']);
        }
    }
    else{
        let unread_filter=true;

        if(readFilter=='read')
            unread_filter=false;

        for(let mail of mails){
            if(mail['unread']==unread_filter){
                gen_mail_item(mail['id'],mail['subject'],mail['mailBody']);
            }
        }
    }
}

function get_userId(){
    let query_string = location.search.substring(1);
    let pattern = /userId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}

function get_activeLink(){
    let query_string = location.search.substring(1);
    let pattern = /active=(\w*)/;
    let active_link = query_string.match(pattern)[1];
    return active_link;
}

function get_readFilter(){
    let query_string = location.search.substring(1);
    let pattern = /readFilter=(\w*)/;
    let readFilter = query_string.match(pattern)[1];
    return readFilter;
}

function recoverMails(){
    let selected_mails = get_selected_mails();

    let url = 'http://localhost:3000/recoverMails';

    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'userId':userId,'id_list':selected_mails})
    }).then(res=>{
        if(res.ok){
            console.log('mails recovered!');
            for(let id of selected_mails){
                $('#'+id).remove();
            }
        }
        else{
            console.log('Failed');
        }
    });

}

function get_selected_mails(){
    let selected_mails = [];
    let mailList = Array.from(document.getElementsByClassName('mail-item'));
    
    for(let mail of mailList){
        
        //checking if checkbox is checked or not
        if(mail.childNodes[0].childNodes[0].checked){
            selected_mails.push(mail.id);
        }
    }
    return selected_mails;
}

//tags
function get_filteredMails(userId,tagList,userType='all',showTrash=false){
    url='http://localhost:3000/get_filteredMails';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'tagList':tagList,'userId':userId,'userType':userType})
    }).then(res=>{
        if(res.ok){
            //display filterd mails
            res.json().then(data=>{
                display_mails(data.data,showTrash);
            });
        }
    });
}

function get_tagFilter(){
    let query_string = location.search.substring(1);
    let pattern = /tagFilter=([^&]*)/;
    let tagFilter = query_string.match(pattern)[1];
    console.log('tagList from home:',tagFilter.length);

    if (tagFilter.length==0)
        return [];
    else
        return tagFilter.split(',');
}

function active_readFilter(){
    if(readFilter!='all'){
        let selctor = '#'+readFilter+'-filter';
        $(selctor).removeClass('info-outline-btn');
        $(selctor).addClass('info-btn');
    }
}

function get_mailList(){

    if(active_link=='inbox'){
        if(tagList.length==0)
            get_received_mailList(userId);
        else
            get_filteredMails(userId,tagList,'receiver');
    }
    else if(active_link=='sent'){
        if(tagList.length==0) 
            get_sent_mailList(userId);
        else
            get_filteredMails(userId,tagList,'sender');  
    }
    else if(active_link=='trash'){
        get_trash_mailList(userId);
    }
    else if(active_link=='spam'){
        get_spam_mailList(userId);
    }
}

get_mailList();
active_readFilter();