$('#hamburger-btn').click(()=>{
    $('.hamburger-menu').animate({left:'0%'},'fast');
});

$('#profile-btn').click(()=>{
  if($('.profile').css('visibility')=='hidden'){
    $('.profile').css({'visibility':'visible','opacity':'1'});
  }
  else{
    $('.profile').css({'visibility':'hidden','opacity':'0'});
  }
 });
 $(document).mouseup(function (e) {
  if ($(e.target).closest(".profile").length === 0) {
    $('.profile').css({'visibility':'hidden','opacity':'0'});
  }
});

function get_userId(){
    let query_string = location.search.substring(1);
    let pattern = /userId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}

function setProfile(name,email){
    $('#user-name').html(name);
    $('#user-mail').html(email);
}

function getUserInfo(id){
    let url = 'http://localhost:3000/getUserInfo';
    fetch(url,{
        method:'POST',
        headers:{
            'Content-Type': 'application/json'
        },
        body:JSON.stringify({'id':id})
    }).then(res=>{
        res.json().then(data=>{
          let userInfo = data.data[0];
          let name = userInfo['firstName']+' '+userInfo['lastName'];
          setProfile(name,userInfo['email']);
        });
    });
}

function logout(){
  let url='./login.html';
  window.location.replace(url);
}

//userId
getUserInfo(get_userId());