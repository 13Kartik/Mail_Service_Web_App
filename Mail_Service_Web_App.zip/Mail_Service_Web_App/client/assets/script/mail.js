let emailId = get_emailId();
let emailStatusId = null;
let activeTags = [];

function get_mailData(emailId){
    url='http://localhost:3000/get_mailData';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'emailId':emailId})
    }).then(res=>{
        if(res.ok){
            res.json().then(data=>{
                let mail=data.data[0];
                set_data(mail);
            });
        }
    });
}

function markAsRead(id){
    url='http://localhost:3000/markAsRead';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'userId':get_userId(),'emailId':id})
    }).then(res=>{
        if(res.ok){
            console.log('marked as read');
        }
    });
}

function set_data(mail){
    console.log(mail);
    $('#subject').html(mail['subject']);
    $('#sender_name').html(mail['firstName']+' '+mail['lastName']);
    $('#sender_mail').html(mail['email']);
    $('#mail_body').html(mail['mailBody']);
    //receiver
    if(mail['receiverId'] != get_userId())
        getReceiverInfo(mail['receiverId']);
}

function get_userId(){
    let query_string = location.search.substring(1);
    let pattern = /userId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}

function get_emailId(){
    let query_string = location.search.substring(1);
    let pattern = /mailId=(\d*)/;
    let userId = query_string.match(pattern)[1];
    return userId;
}

function get_activeLink(){
    let query_string = location.search.substring(1);
    let pattern = /active=(\w*)/;
    let active_link = query_string.match(pattern)[1];
    return active_link;
}

function getReceiverInfo(id) {
    let url = 'http://localhost:3000/getUserInfo';
    fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ 'id': id })
    }).then(res=>{
        res.json().then(data=>{
          let receiverMail = data.data[0]['email'];
          $('#receiver_mail').html('to '+receiverMail)
        });
    });
}  

$('#display-tags').click(() => {
    let tagsPopOver = $('#tags-pop-over');
    let isVisible = tagsPopOver.css('visibility') === 'visible';

    if (isVisible) {
        tagsPopOver.css({ 'visibility': 'hidden', 'opacity': '0' });
    } else {
        tagsPopOver.css({ 'visibility': 'visible', 'opacity': '1' });
    }
});

$(document).click(function (e) {
    let tagsPopOver = $('#tags-pop-over');
    let displayTagsButton = $('#display-tags');

    if (!tagsPopOver.is(e.target) && !displayTagsButton.is(e.target) && tagsPopOver.has(e.target).length === 0) {
        tagsPopOver.css({ 'visibility': 'hidden', 'opacity': '0' });
    }
});

function addTag(tag){
    url='http://localhost:3000/add_tag';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'tagName':tag,'userId':get_userId(),'emailStatusId':emailStatusId})
    }).then(res=>{
        if(res.ok){
            console.log('tag added!!!');
        }
    });
}

function removeTag(tag){
    url='http://localhost:3000/remove_tag';
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'tagName':tag,'emailStatusId':emailStatusId})
    }).then(res=>{
        if(res.ok){
            console.log('tag removed for mail!!!');
        }
    });
}

async function get_emailStatusId(){
    let url='http://localhost:3000/get_emailStatusId'
    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'userId':get_userId(),'emailId':emailId})
    }).then(res=>{
        if(res.ok){
            res.json().then(data=>{
                emailStatusId = data.data[0]['id'];
                console.log('emailStatusId: ',data.data[0]['id']);

                if(data.data[0]['spam']==1)
                    changeSpam_btn();
            })
        }
    });
}

function add_tag_btn(){
    let tag = $('#tag-input').val();

    if(isValidTag(tag)){
        addTag(tag);
    }
    else
        alert('Enter valid tag!');
}

function isValidTag(tag){
    let pattern = /^\w{2,}/;
    return pattern.test(tag);
}

function get_tagList(){
    let url = 'http://localhost:3000/get_tagList';
    fetch(url,{
        method:'POST',
        headers:{
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'userId':get_userId()})
    }).then(res=>{
        if(res.ok){
            res.json().then(tags=>{
                set_tagDatalist(tags.data);
                set_taglist(tags.data);

                get_activeTags().then(activeTags=>{
                    set_mailTags(activeTags.data);
                });
            })
        }
    });
}

function set_tagDatalist(tags){
    for (let tag of tags){
        let option = '<option>'+tag['name']+'</option>';
        $('#tags-list').append(option);
    }
}

function spam_btn(){
    let url = '';

    if($('#spam-btn').attr('class')=='danger-btn')
        url='http://localhost:3000/markAsSpam';
    else
        url='http://localhost:3000/removeFromSpam';

    fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'id':emailStatusId})
    }).then(res=>{
        if(res.ok){
            console.log('marked as spam');
            changeSpam_btn();
        }
    });
}

async function get_activeTags(){
    let url='http://localhost:3000/get_activeTags';

    let res = fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({'id':emailStatusId})
    });

    let data = (await res).json();

    return data;
}

function changeSpam_btn(){
    let btn = $('#spam-btn');
    if(btn.attr('class')=='danger-btn'){
        btn.removeClass('danger-btn');
        btn.addClass('success-btn');
        btn.html('Remove From Spam');
    }
    else{
        btn.removeClass('success-btn');
        btn.addClass('danger-btn');
        btn.html('Mark As Spam');
    }
}

function set_taglist(tags) {
    for (let tag of tags) {
        let tag_item = "<li><input class='nav-tag' type='checkbox' value='" + tag['name'] + "' onclick='toggleTag(this)'><p>" + tag['name'] + "</p></li>";

        $('#mail-add-tags.nav-tags-list').append(tag_item);
    }
}

function toggleTag(cb) {
    if (cb.checked) {
        addTag(cb.value);
    } else {
        removeTag(cb.value);
    }
}

function set_mailTags(tagList) {
    console.log('active Tags: ',tagList);
    console.log('i am alive!!!');
    let parentElement = document.getElementById('mail-add-tags');
    console.log(parentElement);

    let tag_items = parentElement.querySelectorAll('.nav-tag');
    console.log(tag_items);
  
    for (let item of tag_items) {
        item.checked = tagList.some(tag => tag.name == item.value);
    }
}



get_mailData(emailId);
markAsRead(emailId);
get_emailStatusId().then(()=>{
    get_tagList();
});
