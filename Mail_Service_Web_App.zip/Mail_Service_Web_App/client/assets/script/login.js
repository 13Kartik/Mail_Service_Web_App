async function login_btn(){
    
    let email = await $('#email').val(); 
    let password = await $('#password').val();

    console.log('email: ',email);
    console.log('password: ',password);

    login(email,password);
}

function login(email,password){
    let url = 'http://localhost:3000/login';
    fetch(url,{
        method:'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body:JSON.stringify({'email':email,'password':password})
    }).then(res=>{
        console.log(res);
        if(res.ok){
            res.json().then(data=>{
                alert('login successfull !');

                let url='./home.html?userId='+data['id']+'&active=inbox&readFilter=all&tagFilter=';
                window.location.replace(url);
            })
        }
        else{
            alert('Incorrect username or password !')
        }
    });
}