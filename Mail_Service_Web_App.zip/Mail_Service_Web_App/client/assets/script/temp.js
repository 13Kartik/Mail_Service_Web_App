// function current_time(){
//     let date = new Date();
//     let res = date.getFullYear()+'-'+date.getMonth()+'-'+date.getDay()+' '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds();
//     console.log(res);
//     return res;
// }

function current_time(){
    let date = new Date();
    let res = date.getDay()+'-'+date.getMonth()+'-'+date.getFullYear()+' '+date.getHours()+':'+date.getMinutes()+':'+date.getSeconds();
    console.log(res);
    return res;
}

current_time();